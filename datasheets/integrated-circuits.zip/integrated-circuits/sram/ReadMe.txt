MMN2114 -3

4096-Bit NMOS Static RAM

by Microelectronica, Romania, Europe